<?php
/*cargar los archivos necesarios*/
$fuentesJavascript= new array(
"JS/Ajax.js",
"JS/Teclado.js",
"JS/Rectangulos.js",
"JS/Mando.js",
"JS/bucle1.js",
"JS/Dimenciones.js",
"JS/inicio.js"
);
/*bucle automatico*/
foreach($fuentesJavascript as $fuente){
  echo 'esto';
}
